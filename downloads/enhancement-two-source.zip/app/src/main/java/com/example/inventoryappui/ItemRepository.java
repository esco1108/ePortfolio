package com.example.inventoryappui;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// Data access layer for inventory items. This class is responsible only for translating between SQLite rows and InventoryItem objects.

public class ItemRepository {

    private final DatabaseHelper dbHelper;

    public ItemRepository(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public long addItem(String ownerUsername,
                        String name,
                        int quantity,
                        String location,
                        String description,
                        String lastEdited) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return -1;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.I_COL_OWNER, ownerUsername.trim());
        values.put(DatabaseHelper.I_COL_NAME, name);
        values.put(DatabaseHelper.I_COL_QTY, quantity);
        values.put(DatabaseHelper.I_COL_LOCATION, location);
        values.put(DatabaseHelper.I_COL_DESCRIPTION, description == null ? "" : description);
        values.put(DatabaseHelper.I_COL_LAST_EDITED, lastEdited == null ? "" : lastEdited);

        try {
            return db.insertOrThrow(DatabaseHelper.TABLE_ITEMS, null, values);
        } catch (SQLiteException e) {
            return -1;
        }
    }

    public List<InventoryItem> getAllItems(String ownerUsername) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return Collections.emptyList();
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<InventoryItem> results = new ArrayList<>();

        Cursor cursor;
        try {
            cursor = db.query(
                    DatabaseHelper.TABLE_ITEMS,
                    new String[]{
                            DatabaseHelper.I_COL_ID,
                            DatabaseHelper.I_COL_NAME,
                            DatabaseHelper.I_COL_QTY,
                            DatabaseHelper.I_COL_LOCATION,
                            DatabaseHelper.I_COL_DESCRIPTION,
                            DatabaseHelper.I_COL_LAST_EDITED
                    },
                    DatabaseHelper.I_COL_OWNER + "=?",
                    new String[]{ownerUsername.trim()},
                    null,
                    null,
                    null
            );
        } catch (SQLiteException e) {
            return results;
        }

        try {
            int idIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.I_COL_ID);
            int nameIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.I_COL_NAME);
            int qtyIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.I_COL_QTY);
            int locationIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.I_COL_LOCATION);
            int descIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.I_COL_DESCRIPTION);
            int lastEditedIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.I_COL_LAST_EDITED);

            while (cursor.moveToNext()) {
                results.add(new InventoryItem(
                        cursor.getLong(idIndex),
                        ownerUsername.trim(),
                        cursor.getString(nameIndex),
                        cursor.getInt(qtyIndex),
                        cursor.getString(locationIndex),
                        cursor.getString(descIndex),
                        cursor.getString(lastEditedIndex)
                ));
            }
        } finally {
            cursor.close();
        }

        return results;
    }

    public int updateItem(long id,
                          String ownerUsername,
                          String name,
                          int quantity,
                          String location,
                          String description,
                          String lastEdited) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return 0;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.I_COL_NAME, name);
        values.put(DatabaseHelper.I_COL_QTY, quantity);
        values.put(DatabaseHelper.I_COL_LOCATION, location);
        values.put(DatabaseHelper.I_COL_DESCRIPTION, description == null ? "" : description);
        values.put(DatabaseHelper.I_COL_LAST_EDITED, lastEdited == null ? "" : lastEdited);

        try {
            return db.update(
                    DatabaseHelper.TABLE_ITEMS,
                    values,
                    DatabaseHelper.I_COL_ID + "=? AND " + DatabaseHelper.I_COL_OWNER + "=?",
                    new String[]{String.valueOf(id), ownerUsername.trim()}
            );
        } catch (SQLiteException e) {
            return 0;
        }
    }

    public int deleteItem(long id, String ownerUsername) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return 0;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        try {
            return db.delete(
                    DatabaseHelper.TABLE_ITEMS,
                    DatabaseHelper.I_COL_ID + "=? AND " + DatabaseHelper.I_COL_OWNER + "=?",
                    new String[]{String.valueOf(id), ownerUsername.trim()}
            );
        } catch (SQLiteException e) {
            return 0;
        }
    }
}
