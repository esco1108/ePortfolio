package com.example.inventoryappui;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

public class InventoryAlgorithmsTest {

    private final InventoryItem itemA = new InventoryItem(
            1, "user", "Wrench", 8, "Tool Room", "Hand tool", "09/27/26");
    private final InventoryItem itemB = new InventoryItem(
            2, "user", "Bolts", 2, "Bin A", "Steel bolts", "09/27/26");
    private final InventoryItem itemC = new InventoryItem(
            3, "user", "Gloves", 1, "Safety Shelf", "Work gloves", "09/27/26");

    @Test
    public void mergeSortByQuantityAscending_ordersLowestToHighest() {
        List<InventoryItem> sorted = InventoryAlgorithms.mergeSort(
                Arrays.asList(itemA, itemB, itemC),
                InventoryAlgorithms.SortField.QUANTITY,
                true
        );

        assertEquals(1, sorted.get(0).getQuantity());
        assertEquals(2, sorted.get(1).getQuantity());
        assertEquals(8, sorted.get(2).getQuantity());
    }

    @Test
    public void search_matchesNameLocationOrDescription() {
        List<InventoryItem> matches = InventoryAlgorithms.search(
                Arrays.asList(itemA, itemB, itemC), "safety");

        assertEquals(1, matches.size());
        assertEquals("Gloves", matches.get(0).getName());
    }

    @Test
    public void lowStockItems_usesQuantityPriority() {
        List<InventoryItem> lowStock = InventoryAlgorithms.lowStockItems(
                Arrays.asList(itemA, itemB, itemC), 2);

        assertEquals(2, lowStock.size());
        assertEquals("Gloves", lowStock.get(0).getName());
        assertEquals("Bolts", lowStock.get(1).getName());
    }

    @Test
    public void indexById_returnsIndexedItem() {
        Map<Long, InventoryItem> index = InventoryAlgorithms.indexById(
                Arrays.asList(itemA, itemB, itemC));

        assertSame(itemB, index.get(2L));
    }
}
