package com.example.inventoryappui;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ItemValidatorTest {

    @Test
    public void validInput_returnsParsedQuantity() {
        ItemValidator.ValidationResult result =
                ItemValidator.validate("Keyboard", "5", "Storage Room");

        assertTrue(result.isValid());
        assertEquals(5, result.getQuantity());
    }

    @Test
    public void negativeQuantity_isRejected() {
        ItemValidator.ValidationResult result =
                ItemValidator.validate("Keyboard", "-1", "Storage Room");

        assertFalse(result.isValid());
    }

    @Test
    public void missingRequiredValue_isRejected() {
        ItemValidator.ValidationResult result =
                ItemValidator.validate("", "5", "Storage Room");

        assertFalse(result.isValid());
    }
}
