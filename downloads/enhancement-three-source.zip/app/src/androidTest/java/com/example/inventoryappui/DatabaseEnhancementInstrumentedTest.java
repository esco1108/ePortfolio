package com.example.inventoryappui;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;
import java.util.List;

@RunWith(AndroidJUnit4.class)
public class DatabaseEnhancementInstrumentedTest {

    private Context context;

    @Before
    public void setUp() {
        context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        context.deleteDatabase(DatabaseHelper.DB_NAME);
    }

    @After
    public void tearDown() {
        context.deleteDatabase(DatabaseHelper.DB_NAME);
    }

    @Test
    public void schema_enforcesQuantityAndForeignKeyConstraints() {
        UserRepository users = new UserRepository(context);
        assertTrue(users.createUser("vanessa", "password"));

        DatabaseHelper helper = new DatabaseHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        long userId = DatabaseHelper.resolveUserId(db, "vanessa");
        assertTrue(userId > 0);

        ContentValues negativeQuantity = itemValues(userId, "Invalid", -1);
        boolean quantityRejected = false;
        try {
            db.insertOrThrow(DatabaseHelper.TABLE_ITEMS, null, negativeQuantity);
        } catch (SQLiteConstraintException expected) {
            quantityRejected = true;
        }
        assertTrue(quantityRejected);

        ContentValues orphanItem = itemValues(999999, "Orphan", 2);
        boolean foreignKeyRejected = false;
        try {
            db.insertOrThrow(DatabaseHelper.TABLE_ITEMS, null, orphanItem);
        } catch (SQLiteConstraintException expected) {
            foreignKeyRejected = true;
        }
        assertTrue(foreignKeyRejected);
        helper.close();
    }

    @Test
    public void searchItems_filtersRowsInsideSQLite() {
        UserRepository users = new UserRepository(context);
        assertTrue(users.createUser("vanessa", "password"));

        ItemRepository repository = new ItemRepository(context);
        repository.addItem("vanessa", "Wrench", 8, "Tool Room", "Hand tool", "10/04/26");
        repository.addItem("vanessa", "Gloves", 1, "Safety Shelf", "Work gloves", "10/04/26");
        repository.addItem("vanessa", "Bolts", 2, "Bin A", "Steel bolts", "10/04/26");

        List<InventoryItem> matches = repository.searchItems("vanessa", "safety");
        assertEquals(1, matches.size());
        assertEquals("Gloves", matches.get(0).getName());
    }

    @Test
    public void createUser_transactionAlsoCreatesOneSettingsRow() {
        UserRepository users = new UserRepository(context);
        assertTrue(users.createUser("vanessa", "password"));
        assertFalse(users.createUser("vanessa", "different"));

        DatabaseHelper helper = new DatabaseHelper(context);
        SQLiteDatabase db = helper.getReadableDatabase();
        long userId = DatabaseHelper.resolveUserId(db, "vanessa");

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_SMS_SETTINGS,
                new String[]{"COUNT(*)"},
                DatabaseHelper.S_COL_OWNER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                null
        );

        try {
            assertTrue(cursor.moveToFirst());
            assertEquals(1, cursor.getInt(0));
        } finally {
            cursor.close();
            helper.close();
        }
    }

    @Test
    public void schema_createsOwnerAndNameIndexes() {
        DatabaseHelper helper = new DatabaseHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();

        boolean ownerIndexFound = false;
        boolean nameIndexFound = false;
        Cursor cursor = db.rawQuery("PRAGMA index_list(" + DatabaseHelper.TABLE_ITEMS + ")", null);

        try {
            int nameColumn = cursor.getColumnIndexOrThrow("name");
            while (cursor.moveToNext()) {
                String indexName = cursor.getString(nameColumn);
                if (DatabaseHelper.INDEX_ITEMS_OWNER.equals(indexName)) {
                    ownerIndexFound = true;
                }
                if (DatabaseHelper.INDEX_ITEMS_OWNER_NAME.equals(indexName)) {
                    nameIndexFound = true;
                }
            }
        } finally {
            cursor.close();
            helper.close();
        }

        assertTrue(ownerIndexFound);
        assertTrue(nameIndexFound);
    }

    @Test
    public void upgradeFromVersion3_preservesInventoryAndSettings() {
        File databaseFile = context.getDatabasePath(DatabaseHelper.DB_NAME);
        File parent = databaseFile.getParentFile();
        assertNotNull(parent);
        if (!parent.exists()) {
            assertTrue(parent.mkdirs());
        }

        SQLiteDatabase oldDb = SQLiteDatabase.openOrCreateDatabase(databaseFile, null);
        oldDb.execSQL("CREATE TABLE users (_id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password TEXT NOT NULL)");
        oldDb.execSQL("CREATE TABLE items (_id INTEGER PRIMARY KEY AUTOINCREMENT, owner_username TEXT NOT NULL, name TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0, location TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', last_edited TEXT NOT NULL DEFAULT '', FOREIGN KEY(owner_username) REFERENCES users(username))");
        oldDb.execSQL("CREATE TABLE sms_settings (_id INTEGER PRIMARY KEY AUTOINCREMENT, owner_username TEXT NOT NULL UNIQUE, phone_number TEXT NOT NULL DEFAULT '', low_stock_enabled INTEGER NOT NULL DEFAULT 0, permission_choice INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(owner_username) REFERENCES users(username))");
        oldDb.execSQL("INSERT INTO users(username, password) VALUES('vanessa', 'password')");
        oldDb.execSQL("INSERT INTO items(owner_username, name, quantity, location, description, last_edited) VALUES('vanessa', 'Wrench', 8, 'Tool Room', 'Hand tool', '10/04/26')");
        oldDb.execSQL("INSERT INTO sms_settings(owner_username, phone_number, low_stock_enabled, permission_choice) VALUES('vanessa', '5551234567', 1, 1)");
        oldDb.setVersion(3);
        oldDb.close();

        DatabaseHelper helper = new DatabaseHelper(context);
        SQLiteDatabase upgraded = helper.getWritableDatabase();
        assertEquals(4, upgraded.getVersion());

        ItemRepository items = new ItemRepository(context);
        List<InventoryItem> inventory = items.getAllItems("vanessa");
        assertEquals(1, inventory.size());
        assertEquals("Wrench", inventory.get(0).getName());
        assertEquals(8, inventory.get(0).getQuantity());

        SmsSettings settings = new SmsSettingsRepository(context).getSettings("vanessa");
        assertEquals("5551234567", settings.phoneNumber);
        assertTrue(settings.lowStockEnabled);
        assertEquals(SmsSettings.CHOICE_ACCEPTED, settings.permissionChoice);

        helper.close();
    }

    private ContentValues itemValues(long ownerId, String name, int quantity) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.I_COL_OWNER_ID, ownerId);
        values.put(DatabaseHelper.I_COL_NAME, name);
        values.put(DatabaseHelper.I_COL_QTY, quantity);
        values.put(DatabaseHelper.I_COL_LOCATION, "Test Location");
        values.put(DatabaseHelper.I_COL_DESCRIPTION, "Test Description");
        values.put(DatabaseHelper.I_COL_LAST_EDITED, "10/04/26");
        return values;
    }
}
