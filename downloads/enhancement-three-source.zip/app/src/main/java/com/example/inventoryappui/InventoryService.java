package com.example.inventoryappui;

import java.util.Collections;
import java.util.List;

// Service layer for inventory operations. The Activity handles presentation,
// this class handles validation/workflow/algorithms, and ItemRepository handles SQLite.

public class InventoryService {

    private final ItemRepository repository;

    public InventoryService(ItemRepository repository) {
        this.repository = repository;
    }

    public List<InventoryItem> getItems(String ownerUsername) {
        return getItems(ownerUsername, InventoryAlgorithms.SortField.NAME, true);
    }

    public List<InventoryItem> getItems(String ownerUsername,
                                        InventoryAlgorithms.SortField sortField,
                                        boolean ascending) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return Collections.emptyList();
        }

        List<InventoryItem> items = repository.getAllItems(ownerUsername.trim());
        return InventoryAlgorithms.mergeSort(items, sortField, ascending);
    }

    public List<InventoryItem> searchItems(String ownerUsername,
                                           String query,
                                           InventoryAlgorithms.SortField sortField,
                                           boolean ascending) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return Collections.emptyList();
        }

        List<InventoryItem> matches = repository.searchItems(ownerUsername.trim(), query);
        return InventoryAlgorithms.mergeSort(matches, sortField, ascending);
    }

    public List<InventoryItem> getLowStockItems(String ownerUsername, int threshold) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return Collections.emptyList();
        }

        List<InventoryItem> items = repository.getAllItems(ownerUsername.trim());
        return InventoryAlgorithms.lowStockItems(items, threshold);
    }

    public InventoryItem getItemById(String ownerUsername, long itemId) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return null;
        }

        return repository.getItemById(ownerUsername.trim(), itemId);
    }

    public OperationResult addItem(String ownerUsername,
                                   String name,
                                   String quantityText,
                                   String location,
                                   String description,
                                   String lastEdited) {
        ItemValidator.ValidationResult validation =
                ItemValidator.validate(name, quantityText, location);

        if (!validation.isValid()) {
            return OperationResult.failure(validation.getMessage());
        }

        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return OperationResult.failure("No signed-in user was found.");
        }

        long itemId = repository.addItem(
                ownerUsername.trim(),
                name.trim(),
                validation.getQuantity(),
                location.trim(),
                normalizeDescription(description),
                normalizeText(lastEdited)
        );

        if (itemId == -1) {
            return OperationResult.failure("Failed to add item.");
        }

        return OperationResult.success(itemId, validation.getQuantity());
    }

    public OperationResult updateItem(long itemId,
                                      String ownerUsername,
                                      String name,
                                      String quantityText,
                                      String location,
                                      String description,
                                      String lastEdited) {
        ItemValidator.ValidationResult validation =
                ItemValidator.validate(name, quantityText, location);

        if (!validation.isValid()) {
            return OperationResult.failure(validation.getMessage());
        }

        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return OperationResult.failure("No signed-in user was found.");
        }

        int rowsUpdated = repository.updateItem(
                itemId,
                ownerUsername.trim(),
                name.trim(),
                validation.getQuantity(),
                location.trim(),
                normalizeDescription(description),
                normalizeText(lastEdited)
        );

        if (rowsUpdated != 1) {
            return OperationResult.failure("Failed to update item.");
        }

        return OperationResult.success(itemId, validation.getQuantity());
    }

    public OperationResult deleteItem(long itemId, String ownerUsername) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return OperationResult.failure("No signed-in user was found.");
        }

        int rowsDeleted = repository.deleteItem(itemId, ownerUsername.trim());
        if (rowsDeleted != 1) {
            return OperationResult.failure("Failed to delete item.");
        }

        return OperationResult.success(itemId, 0);
    }

    private String normalizeDescription(String description) {
        String cleanDescription = normalizeText(description);
        return cleanDescription.isEmpty() ? "No description provided." : cleanDescription;
    }

    private String normalizeText(String value) {
        return value == null ? "" : value.trim();
    }

    public static final class OperationResult {
        private final boolean successful;
        private final String message;
        private final long itemId;
        private final int quantity;

        private OperationResult(boolean successful, String message, long itemId, int quantity) {
            this.successful = successful;
            this.message = message;
            this.itemId = itemId;
            this.quantity = quantity;
        }

        public static OperationResult success(long itemId, int quantity) {
            return new OperationResult(true, "", itemId, quantity);
        }

        public static OperationResult failure(String message) {
            return new OperationResult(false, message, -1, 0);
        }

        public boolean isSuccessful() {
            return successful;
        }

        public String getMessage() {
            return message;
        }

        public long getItemId() {
            return itemId;
        }

        public int getQuantity() {
            return quantity;
        }
    }
}
