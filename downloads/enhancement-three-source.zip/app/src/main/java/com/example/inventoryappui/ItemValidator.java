package com.example.inventoryappui;

// Centralizes inventory input rules so Activities do not duplicate validation.

public final class ItemValidator {

    private static final int MAX_NAME_LENGTH = 80;
    private static final int MAX_LOCATION_LENGTH = 120;

    private ItemValidator() {
        // Utility class; prevent instantiation.
    }

    public static ValidationResult validate(String name, String quantityText, String location) {
        String safeName = name == null ? "" : name.trim();
        String safeQuantity = quantityText == null ? "" : quantityText.trim();
        String safeLocation = location == null ? "" : location.trim();

        if (safeName.isEmpty() || safeQuantity.isEmpty() || safeLocation.isEmpty()) {
            return ValidationResult.invalid("Name, quantity, and location are required.");
        }

        if (safeName.length() > MAX_NAME_LENGTH) {
            return ValidationResult.invalid("Item name must be 80 characters or fewer.");
        }

        if (safeLocation.length() > MAX_LOCATION_LENGTH) {
            return ValidationResult.invalid("Location must be 120 characters or fewer.");
        }

        final int quantity;
        try {
            quantity = Integer.parseInt(safeQuantity);
        } catch (NumberFormatException e) {
            return ValidationResult.invalid("Quantity must be a valid whole number.");
        }

        if (quantity < 0) {
            return ValidationResult.invalid("Quantity cannot be negative.");
        }

        return ValidationResult.valid(quantity);
    }

    public static final class ValidationResult {
        private final boolean valid;
        private final String message;
        private final int quantity;

        private ValidationResult(boolean valid, String message, int quantity) {
            this.valid = valid;
            this.message = message;
            this.quantity = quantity;
        }

        public static ValidationResult valid(int quantity) {
            return new ValidationResult(true, "", quantity);
        }

        public static ValidationResult invalid(String message) {
            return new ValidationResult(false, message, 0);
        }

        public boolean isValid() {
            return valid;
        }

        public String getMessage() {
            return message;
        }

        public int getQuantity() {
            return quantity;
        }
    }
}
