package com.example.inventoryappui;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// Data access layer for inventory items
public class ItemRepository {

    private final DatabaseHelper dbHelper;

    public ItemRepository(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public long addItem(String ownerUsername,
                        String name,
                        int quantity,
                        String location,
                        String description,
                        String lastEdited) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return -1;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long ownerId = DatabaseHelper.resolveUserId(db, ownerUsername);
        if (ownerId == -1) {
            return -1;
        }

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.I_COL_OWNER_ID, ownerId);
        values.put(DatabaseHelper.I_COL_NAME, name);
        values.put(DatabaseHelper.I_COL_QTY, quantity);
        values.put(DatabaseHelper.I_COL_LOCATION, location);
        values.put(DatabaseHelper.I_COL_DESCRIPTION, description == null ? "" : description);
        values.put(DatabaseHelper.I_COL_LAST_EDITED, lastEdited == null ? "" : lastEdited);

        try {
            return db.insertOrThrow(DatabaseHelper.TABLE_ITEMS, null, values);
        } catch (SQLiteException e) {
            return -1;
        }
    }

    public List<InventoryItem> getAllItems(String ownerUsername) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return Collections.emptyList();
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        long ownerId = DatabaseHelper.resolveUserId(db, ownerUsername);
        if (ownerId == -1) {
            return Collections.emptyList();
        }

        return queryItems(
                db,
                ownerUsername.trim(),
                DatabaseHelper.I_COL_OWNER_ID + "=?",
                new String[]{String.valueOf(ownerId)}
        );
    }

    // Search inventory in SQLite
    public List<InventoryItem> searchItems(String ownerUsername, String query) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return Collections.emptyList();
        }

        String cleanQuery = query == null ? "" : query.trim();
        if (cleanQuery.isEmpty()) {
            return getAllItems(ownerUsername);
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        long ownerId = DatabaseHelper.resolveUserId(db, ownerUsername);
        if (ownerId == -1) {
            return Collections.emptyList();
        }

        String pattern = "%" + escapeLikeValue(cleanQuery) + "%";
        String selection = DatabaseHelper.I_COL_OWNER_ID + "=? AND (" +
                DatabaseHelper.I_COL_NAME + " LIKE ? ESCAPE '\\' COLLATE NOCASE OR " +
                DatabaseHelper.I_COL_LOCATION + " LIKE ? ESCAPE '\\' COLLATE NOCASE OR " +
                DatabaseHelper.I_COL_DESCRIPTION + " LIKE ? ESCAPE '\\' COLLATE NOCASE)";

        return queryItems(
                db,
                ownerUsername.trim(),
                selection,
                new String[]{String.valueOf(ownerId), pattern, pattern, pattern}
        );
    }

    // Find one item by ID
    public InventoryItem getItemById(String ownerUsername, long itemId) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return null;
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        long ownerId = DatabaseHelper.resolveUserId(db, ownerUsername);
        if (ownerId == -1) {
            return null;
        }

        List<InventoryItem> matches = queryItems(
                db,
                ownerUsername.trim(),
                DatabaseHelper.I_COL_ID + "=? AND " + DatabaseHelper.I_COL_OWNER_ID + "=?",
                new String[]{String.valueOf(itemId), String.valueOf(ownerId)}
        );

        return matches.isEmpty() ? null : matches.get(0);
    }

    public int updateItem(long id,
                          String ownerUsername,
                          String name,
                          int quantity,
                          String location,
                          String description,
                          String lastEdited) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return 0;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long ownerId = DatabaseHelper.resolveUserId(db, ownerUsername);
        if (ownerId == -1) {
            return 0;
        }

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.I_COL_NAME, name);
        values.put(DatabaseHelper.I_COL_QTY, quantity);
        values.put(DatabaseHelper.I_COL_LOCATION, location);
        values.put(DatabaseHelper.I_COL_DESCRIPTION, description == null ? "" : description);
        values.put(DatabaseHelper.I_COL_LAST_EDITED, lastEdited == null ? "" : lastEdited);

        try {
            return db.update(
                    DatabaseHelper.TABLE_ITEMS,
                    values,
                    DatabaseHelper.I_COL_ID + "=? AND " + DatabaseHelper.I_COL_OWNER_ID + "=?",
                    new String[]{String.valueOf(id), String.valueOf(ownerId)}
            );
        } catch (SQLiteException e) {
            return 0;
        }
    }

    public int deleteItem(long id, String ownerUsername) {
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            return 0;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long ownerId = DatabaseHelper.resolveUserId(db, ownerUsername);
        if (ownerId == -1) {
            return 0;
        }

        try {
            return db.delete(
                    DatabaseHelper.TABLE_ITEMS,
                    DatabaseHelper.I_COL_ID + "=? AND " + DatabaseHelper.I_COL_OWNER_ID + "=?",
                    new String[]{String.valueOf(id), String.valueOf(ownerId)}
            );
        } catch (SQLiteException e) {
            return 0;
        }
    }

    private List<InventoryItem> queryItems(SQLiteDatabase db,
                                           String ownerUsername,
                                           String selection,
                                           String[] selectionArgs) {
        List<InventoryItem> results = new ArrayList<>();
        Cursor cursor;

        try {
            cursor = db.query(
                    DatabaseHelper.TABLE_ITEMS,
                    new String[]{
                            DatabaseHelper.I_COL_ID,
                            DatabaseHelper.I_COL_NAME,
                            DatabaseHelper.I_COL_QTY,
                            DatabaseHelper.I_COL_LOCATION,
                            DatabaseHelper.I_COL_DESCRIPTION,
                            DatabaseHelper.I_COL_LAST_EDITED
                    },
                    selection,
                    selectionArgs,
                    null,
                    null,
                    null
            );
        } catch (SQLiteException e) {
            return results;
        }

        try {
            int idIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.I_COL_ID);
            int nameIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.I_COL_NAME);
            int qtyIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.I_COL_QTY);
            int locationIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.I_COL_LOCATION);
            int descIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.I_COL_DESCRIPTION);
            int lastEditedIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.I_COL_LAST_EDITED);

            while (cursor.moveToNext()) {
                results.add(new InventoryItem(
                        cursor.getLong(idIndex),
                        ownerUsername,
                        cursor.getString(nameIndex),
                        cursor.getInt(qtyIndex),
                        cursor.getString(locationIndex),
                        cursor.getString(descIndex),
                        cursor.getString(lastEditedIndex)
                ));
            }
        } finally {
            cursor.close();
        }

        return results;
    }

    private String escapeLikeValue(String value) {
        return value
                .replace("\\", "\\\\")
                .replace("%", "\\%")
                .replace("_", "\\_");
    }
}
