package com.example.inventoryappui;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

// Persists SMS settings per user in SQLite
public class SmsSettingsRepository {

    private final DatabaseHelper dbHelper;

    public SmsSettingsRepository(Context context) {
        this.dbHelper = new DatabaseHelper(context);
    }

    public SmsSettings getSettings(String ownerUsername) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long ownerId = DatabaseHelper.resolveUserId(db, ownerUsername);
        if (ownerId == -1) {
            return defaultSettings();
        }

        ensureRow(db, ownerId);

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_SMS_SETTINGS,
                new String[]{
                        DatabaseHelper.S_COL_PHONE,
                        DatabaseHelper.S_COL_LOW_STOCK_ENABLED,
                        DatabaseHelper.S_COL_PERMISSION_CHOICE
                },
                DatabaseHelper.S_COL_OWNER_ID + "=?",
                new String[]{String.valueOf(ownerId)},
                null,
                null,
                null,
                "1"
        );

        try {
            if (cursor.moveToFirst()) {
                String phone = cursor.getString(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.S_COL_PHONE));
                int enabledInt = cursor.getInt(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.S_COL_LOW_STOCK_ENABLED));
                int choice = cursor.getInt(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.S_COL_PERMISSION_CHOICE));

                return new SmsSettings(
                        phone == null ? "" : phone,
                        enabledInt == 1,
                        choice
                );
            }
        } finally {
            cursor.close();
        }

        return defaultSettings();
    }

    public void saveSettings(String ownerUsername, String phoneNumber, boolean lowStockEnabled) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long ownerId = DatabaseHelper.resolveUserId(db, ownerUsername);
        if (ownerId == -1) {
            return;
        }

        ensureRow(db, ownerId);

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.S_COL_PHONE, phoneNumber == null ? "" : phoneNumber.trim());
        values.put(DatabaseHelper.S_COL_LOW_STOCK_ENABLED, lowStockEnabled ? 1 : 0);

        db.update(
                DatabaseHelper.TABLE_SMS_SETTINGS,
                values,
                DatabaseHelper.S_COL_OWNER_ID + "=?",
                new String[]{String.valueOf(ownerId)}
        );
    }

    public void setPermissionChoice(String ownerUsername, int choice) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long ownerId = DatabaseHelper.resolveUserId(db, ownerUsername);
        if (ownerId == -1) {
            return;
        }

        ensureRow(db, ownerId);

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.S_COL_PERMISSION_CHOICE, choice);

        db.update(
                DatabaseHelper.TABLE_SMS_SETTINGS,
                values,
                DatabaseHelper.S_COL_OWNER_ID + "=?",
                new String[]{String.valueOf(ownerId)}
        );
    }

    // Create default settings if they do not already exist
    private void ensureRow(SQLiteDatabase db, long ownerId) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.S_COL_OWNER_ID, ownerId);
        values.put(DatabaseHelper.S_COL_PHONE, "");
        values.put(DatabaseHelper.S_COL_LOW_STOCK_ENABLED, 0);
        values.put(DatabaseHelper.S_COL_PERMISSION_CHOICE, SmsSettings.CHOICE_UNKNOWN);

        db.insertWithOnConflict(
                DatabaseHelper.TABLE_SMS_SETTINGS,
                null,
                values,
                SQLiteDatabase.CONFLICT_IGNORE
        );
    }

    private SmsSettings defaultSettings() {
        return new SmsSettings("", false, SmsSettings.CHOICE_UNKNOWN);
    }
}
