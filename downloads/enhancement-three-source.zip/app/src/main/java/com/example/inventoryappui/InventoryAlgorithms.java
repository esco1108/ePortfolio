package com.example.inventoryappui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;

public final class InventoryAlgorithms {

    public enum SortField {
        NAME,
        QUANTITY,
        LOCATION
    }

    private InventoryAlgorithms() {
        // Utility class; prevent instantiation.
    }

    public static List<InventoryItem> mergeSort(List<InventoryItem> items,
                                                SortField sortField,
                                                boolean ascending) {
        List<InventoryItem> result = items == null
                ? new ArrayList<>()
                : new ArrayList<>(items);

        if (result.size() < 2) {
            return result;
        }

        List<InventoryItem> temp = new ArrayList<>(result);
        mergeSort(result, temp, 0, result.size() - 1, sortField, ascending);
        return result;
    }

    private static void mergeSort(List<InventoryItem> values,
                                  List<InventoryItem> temp,
                                  int left,
                                  int right,
                                  SortField sortField,
                                  boolean ascending) {
        if (left >= right) {
            return;
        }

        int middle = left + (right - left) / 2;
        mergeSort(values, temp, left, middle, sortField, ascending);
        mergeSort(values, temp, middle + 1, right, sortField, ascending);
        merge(values, temp, left, middle, right, sortField, ascending);
    }

    private static void merge(List<InventoryItem> values,
                              List<InventoryItem> temp,
                              int left,
                              int middle,
                              int right,
                              SortField sortField,
                              boolean ascending) {
        for (int i = left; i <= right; i++) {
            temp.set(i, values.get(i));
        }

        int leftIndex = left;
        int rightIndex = middle + 1;
        int writeIndex = left;

        while (leftIndex <= middle && rightIndex <= right) {
            InventoryItem leftItem = temp.get(leftIndex);
            InventoryItem rightItem = temp.get(rightIndex);

            if (compare(leftItem, rightItem, sortField, ascending) <= 0) {
                values.set(writeIndex++, leftItem);
                leftIndex++;
            } else {
                values.set(writeIndex++, rightItem);
                rightIndex++;
            }
        }

        while (leftIndex <= middle) {
            values.set(writeIndex++, temp.get(leftIndex++));
        }

        while (rightIndex <= right) {
            values.set(writeIndex++, temp.get(rightIndex++));
        }
    }

    public static List<InventoryItem> search(List<InventoryItem> items, String query) {
        List<InventoryItem> matches = new ArrayList<>();
        if (items == null) {
            return matches;
        }

        String normalizedQuery = normalize(query);
        if (normalizedQuery.isEmpty()) {
            matches.addAll(items);
            return matches;
        }

        for (InventoryItem item : items) {
            if (contains(item.getName(), normalizedQuery)
                    || contains(item.getLocation(), normalizedQuery)
                    || contains(item.getDescription(), normalizedQuery)) {
                matches.add(item);
            }
        }

        return matches;
    }

    public static List<InventoryItem> lowStockItems(List<InventoryItem> items, int threshold) {
        PriorityQueue<InventoryItem> queue = new PriorityQueue<>(
                Comparator.comparingInt(InventoryItem::getQuantity)
                        .thenComparing(item -> normalize(item.getName()))
                        .thenComparingLong(InventoryItem::getId)
        );

        if (items != null) {
            for (InventoryItem item : items) {
                if (item.getQuantity() <= threshold) {
                    queue.offer(item);
                }
            }
        }

        List<InventoryItem> result = new ArrayList<>();
        while (!queue.isEmpty()) {
            result.add(queue.poll());
        }
        return result;
    }

    public static Map<Long, InventoryItem> indexById(List<InventoryItem> items) {
        Map<Long, InventoryItem> index = new HashMap<>();
        if (items != null) {
            for (InventoryItem item : items) {
                index.put(item.getId(), item);
            }
        }
        return index;
    }

    private static int compare(InventoryItem first,
                               InventoryItem second,
                               SortField sortField,
                               boolean ascending) {
        int result;

        if (sortField == SortField.QUANTITY) {
            result = Integer.compare(first.getQuantity(), second.getQuantity());
        } else if (sortField == SortField.LOCATION) {
            result = normalize(first.getLocation()).compareTo(normalize(second.getLocation()));
        } else {
            result = normalize(first.getName()).compareTo(normalize(second.getName()));
        }

        // Deterministic tie-breakers keep the displayed order stable.
        if (result == 0) {
            result = normalize(first.getName()).compareTo(normalize(second.getName()));
        }
        if (result == 0) {
            result = Long.compare(first.getId(), second.getId());
        }

        return ascending ? result : -result;
    }

    private static boolean contains(String value, String normalizedQuery) {
        return normalize(value).contains(normalizedQuery);
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
    }
}
