package com.example.inventoryappui;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

// Displays inventory items in SQLite grid

public class ItemsActivity extends AppCompatActivity {

    private InventoryService inventoryService;
    private ItemsGridAdapter adapter;
    private String ownerUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);
        setTitle("SQLite Grid Screen");

        ownerUsername = SessionManager.getCurrentUsername(this);
        if (ownerUsername == null || ownerUsername.trim().isEmpty()) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        inventoryService = new InventoryService(new ItemRepository(this));

        if (inventoryService.getItems(ownerUsername).isEmpty()) {
            inventoryService.addItem(
                    ownerUsername,
                    "Test Item A",
                    "3",
                    "Storage Room",
                    "Seed item",
                    nowDate()
            );
            inventoryService.addItem(
                    ownerUsername,
                    "Test Item B",
                    "7",
                    "Front Shelf",
                    "Seed item",
                    nowDate()
            );
        }

        RecyclerView recyclerView = findViewById(R.id.recyclerItems);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        List<InventoryItem> data = inventoryService.getItems(ownerUsername);
        adapter = new ItemsGridAdapter(data);
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adapter != null && inventoryService != null) {
            adapter.setData(inventoryService.getItems(ownerUsername));
        }
    }

    private String nowDate() {
        return new SimpleDateFormat("MM/dd/yyyy hh:mm a", Locale.US).format(new Date());
    }
}
