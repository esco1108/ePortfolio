package com.example.inventoryappui;

// Immutable inventory model shared by the UI, service, and repository layers.
// Keeping the model separate from the repository makes each class responsible
// for one part of the application.

public class InventoryItem {
    private final long id;
    private final String ownerUsername;
    private final String name;
    private final int quantity;
    private final String location;
    private final String description;
    private final String lastEdited;

    public InventoryItem(long id,
                         String ownerUsername,
                         String name,
                         int quantity,
                         String location,
                         String description,
                         String lastEdited) {
        this.id = id;
        this.ownerUsername = ownerUsername;
        this.name = name;
        this.quantity = quantity;
        this.location = location;
        this.description = description;
        this.lastEdited = lastEdited;
    }

    public long getId() {
        return id;
    }

    public String getOwnerUsername() {
        return ownerUsername;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getLocation() {
        return location;
    }

    public String getDescription() {
        return description;
    }

    public String getLastEdited() {
        return lastEdited;
    }
}
