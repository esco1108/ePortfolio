package com.example.inventoryappui;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

// Handles user account creation and login validation
public class UserRepository {

    private final DatabaseHelper dbHelper;

    public UserRepository(Context context) {
        this.dbHelper = new DatabaseHelper(context);
    }

    // Creates a new user and default settings
    public boolean createUser(String username, String password) {
        if (username == null || password == null) return false;

        username = username.trim();
        if (username.isEmpty() || password.isEmpty()) return false;

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.beginTransaction();

        try {
            ContentValues userValues = new ContentValues();
            userValues.put(DatabaseHelper.U_COL_USERNAME, username);
            userValues.put(DatabaseHelper.U_COL_PASSWORD, password);

            long userId = db.insertOrThrow(DatabaseHelper.TABLE_USERS, null, userValues);

            ContentValues settingsValues = new ContentValues();
            settingsValues.put(DatabaseHelper.S_COL_OWNER_ID, userId);
            settingsValues.put(DatabaseHelper.S_COL_PHONE, "");
            settingsValues.put(DatabaseHelper.S_COL_LOW_STOCK_ENABLED, 0);
            settingsValues.put(DatabaseHelper.S_COL_PERMISSION_CHOICE, SmsSettings.CHOICE_UNKNOWN);
            db.insertOrThrow(DatabaseHelper.TABLE_SMS_SETTINGS, null, settingsValues);

            db.setTransactionSuccessful();
            return true;
        } catch (SQLiteException e) {
            return false;
        } finally {
            db.endTransaction();
        }
    }

    public boolean validateUser(String username, String password) {
        if (username == null || password == null) return false;

        username = username.trim();
        if (username.isEmpty() || password.isEmpty()) return false;

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_USERS,
                new String[]{DatabaseHelper.U_COL_PASSWORD},
                DatabaseHelper.U_COL_USERNAME + "=?",
                new String[]{username},
                null,
                null,
                null,
                "1"
        );

        try {
            if (!cursor.moveToFirst()) {
                return false;
            }

            String stored = cursor.getString(
                    cursor.getColumnIndexOrThrow(DatabaseHelper.U_COL_PASSWORD)
            );
            return password.equals(stored);
        } finally {
            cursor.close();
        }
    }

    public boolean userExists(String username) {
        if (username == null || username.trim().isEmpty()) {
            return false;
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_USERS,
                new String[]{DatabaseHelper.U_COL_ID},
                DatabaseHelper.U_COL_USERNAME + "=?",
                new String[]{username.trim()},
                null,
                null,
                null,
                "1"
        );

        try {
            return cursor.moveToFirst();
        } finally {
            cursor.close();
        }
    }
}
