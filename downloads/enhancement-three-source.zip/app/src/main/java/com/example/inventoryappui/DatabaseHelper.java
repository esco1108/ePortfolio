package com.example.inventoryappui;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database
    public static final String DB_NAME = "inventory_app.db";
    public static final int DB_VERSION = 4;

    // users
    public static final String TABLE_USERS = "users";
    public static final String U_COL_ID = "_id";
    public static final String U_COL_USERNAME = "username";
    public static final String U_COL_PASSWORD = "password";

    // items
    public static final String TABLE_ITEMS = "items";
    public static final String I_COL_ID = "_id";
    public static final String I_COL_OWNER_ID = "owner_user_id";
    public static final String I_COL_NAME = "name";
    public static final String I_COL_QTY = "quantity";
    public static final String I_COL_LOCATION = "location";
    public static final String I_COL_DESCRIPTION = "description";
    public static final String I_COL_LAST_EDITED = "last_edited";

    // sms_settings
    public static final String TABLE_SMS_SETTINGS = "sms_settings";
    public static final String S_COL_ID = "_id";
    public static final String S_COL_OWNER_ID = "owner_user_id";
    public static final String S_COL_PHONE = "phone_number";
    public static final String S_COL_LOW_STOCK_ENABLED = "low_stock_enabled";
    public static final String S_COL_PERMISSION_CHOICE = "permission_choice";

    // Indexes
    public static final String INDEX_ITEMS_OWNER = "idx_items_owner_user_id";
    public static final String INDEX_ITEMS_OWNER_NAME = "idx_items_owner_name";

    private static final String SQL_CREATE_USERS =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    U_COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    U_COL_USERNAME + " TEXT NOT NULL UNIQUE, " +
                    U_COL_PASSWORD + " TEXT NOT NULL" +
                    ");";

    private static String createItemsTableSql(String tableName) {
        return "CREATE TABLE " + tableName + " (" +
                I_COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                I_COL_OWNER_ID + " INTEGER NOT NULL, " +
                I_COL_NAME + " TEXT NOT NULL, " +
                I_COL_QTY + " INTEGER NOT NULL DEFAULT 0 CHECK(" + I_COL_QTY + " >= 0), " +
                I_COL_LOCATION + " TEXT NOT NULL, " +
                I_COL_DESCRIPTION + " TEXT NOT NULL DEFAULT '', " +
                I_COL_LAST_EDITED + " TEXT NOT NULL DEFAULT '', " +
                "FOREIGN KEY(" + I_COL_OWNER_ID + ") REFERENCES " +
                TABLE_USERS + "(" + U_COL_ID + ") ON DELETE CASCADE" +
                ");";
    }

    private static String createSmsSettingsTableSql(String tableName) {
        return "CREATE TABLE " + tableName + " (" +
                S_COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                S_COL_OWNER_ID + " INTEGER NOT NULL UNIQUE, " +
                S_COL_PHONE + " TEXT NOT NULL DEFAULT '', " +
                S_COL_LOW_STOCK_ENABLED + " INTEGER NOT NULL DEFAULT 0 " +
                "CHECK(" + S_COL_LOW_STOCK_ENABLED + " IN (0, 1)), " +
                S_COL_PERMISSION_CHOICE + " INTEGER NOT NULL DEFAULT 0 " +
                "CHECK(" + S_COL_PERMISSION_CHOICE + " IN (0, 1, 2)), " +
                "FOREIGN KEY(" + S_COL_OWNER_ID + ") REFERENCES " +
                TABLE_USERS + "(" + U_COL_ID + ") ON DELETE CASCADE" +
                ");";
    }

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        // Enable foreign key checks
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_USERS);
        db.execSQL(createItemsTableSql(TABLE_ITEMS));
        db.execSQL(createSmsSettingsTableSql(TABLE_SMS_SETTINGS));
        createIndexes(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion == 3 && newVersion >= 4) {
            // Migrate existing version 3 data
            migrateVersion3To4(db);
            return;
        }

        // Recreate older database versions
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SMS_SETTINGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    private void migrateVersion3To4(SQLiteDatabase db) {
        final String oldOwnerColumn = "owner_username";
        final String itemsV4 = TABLE_ITEMS + "_v4";
        final String smsV4 = TABLE_SMS_SETTINGS + "_v4";

        db.execSQL(createItemsTableSql(itemsV4));
        db.execSQL(createSmsSettingsTableSql(smsV4));

        // Convert username ownership to user IDs
        db.execSQL(
                "INSERT INTO " + itemsV4 + " (" +
                        I_COL_ID + ", " + I_COL_OWNER_ID + ", " + I_COL_NAME + ", " +
                        I_COL_QTY + ", " + I_COL_LOCATION + ", " + I_COL_DESCRIPTION + ", " +
                        I_COL_LAST_EDITED + ") " +
                        "SELECT i." + I_COL_ID + ", u." + U_COL_ID + ", i." + I_COL_NAME + ", " +
                        "CASE WHEN i." + I_COL_QTY + " < 0 THEN 0 ELSE i." + I_COL_QTY + " END, " +
                        "i." + I_COL_LOCATION + ", COALESCE(i." + I_COL_DESCRIPTION + ", ''), " +
                        "COALESCE(i." + I_COL_LAST_EDITED + ", '') " +
                        "FROM " + TABLE_ITEMS + " i INNER JOIN " + TABLE_USERS + " u " +
                        "ON u." + U_COL_USERNAME + " = i." + oldOwnerColumn
        );

        db.execSQL(
                "INSERT INTO " + smsV4 + " (" +
                        S_COL_ID + ", " + S_COL_OWNER_ID + ", " + S_COL_PHONE + ", " +
                        S_COL_LOW_STOCK_ENABLED + ", " + S_COL_PERMISSION_CHOICE + ") " +
                        "SELECT s." + S_COL_ID + ", u." + U_COL_ID + ", " +
                        "COALESCE(s." + S_COL_PHONE + ", ''), " +
                        "CASE WHEN s." + S_COL_LOW_STOCK_ENABLED + " = 1 THEN 1 ELSE 0 END, " +
                        "CASE WHEN s." + S_COL_PERMISSION_CHOICE + " IN (0,1,2) " +
                        "THEN s." + S_COL_PERMISSION_CHOICE + " ELSE 0 END " +
                        "FROM " + TABLE_SMS_SETTINGS + " s INNER JOIN " + TABLE_USERS + " u " +
                        "ON u." + U_COL_USERNAME + " = s." + oldOwnerColumn
        );

        db.execSQL("DROP TABLE " + TABLE_ITEMS);
        db.execSQL("DROP TABLE " + TABLE_SMS_SETTINGS);
        db.execSQL("ALTER TABLE " + itemsV4 + " RENAME TO " + TABLE_ITEMS);
        db.execSQL("ALTER TABLE " + smsV4 + " RENAME TO " + TABLE_SMS_SETTINGS);
        createIndexes(db);
    }

    private void createIndexes(SQLiteDatabase db) {
        db.execSQL(
                "CREATE INDEX IF NOT EXISTS " + INDEX_ITEMS_OWNER +
                        " ON " + TABLE_ITEMS + "(" + I_COL_OWNER_ID + ")"
        );
        db.execSQL(
                "CREATE INDEX IF NOT EXISTS " + INDEX_ITEMS_OWNER_NAME +
                        " ON " + TABLE_ITEMS + "(" + I_COL_OWNER_ID + ", " +
                        I_COL_NAME + " COLLATE NOCASE)"
        );
    }

    // Find the user ID for a username
    static long resolveUserId(SQLiteDatabase db, String username) {
        if (db == null || username == null || username.trim().isEmpty()) {
            return -1;
        }

        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{U_COL_ID},
                U_COL_USERNAME + "=?",
                new String[]{username.trim()},
                null,
                null,
                null,
                "1"
        );

        try {
            if (!cursor.moveToFirst()) {
                return -1;
            }
            return cursor.getLong(cursor.getColumnIndexOrThrow(U_COL_ID));
        } finally {
            cursor.close();
        }
    }
}
